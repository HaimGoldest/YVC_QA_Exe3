package Statment_Brancch_coverage.Statment_Brancch_coverage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        WeakMethod_Ex1A.class,
        WeakMethod_Ex1B.class,
        WeakMethod_Ex2A.class,
        WeakMethod_Ex2B.class,
        WeakMethod_Ex3A.class,
        WeakMethod_Ex3B.class,
        WeakMethod_Ex4A.class,
        WeakMethod_Ex4B.class,        
})

public class TestSuite {



}
